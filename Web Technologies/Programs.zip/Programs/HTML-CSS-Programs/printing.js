"use strict";
function PrintPage()
{
    window.print();
}
